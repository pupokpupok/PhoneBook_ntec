$cd build
$ ./example-postgresql-exe  # - run application.

Go to [http://localhost:8000/swagger/ui](http://localhost:8000/swagger/ui) to try endpoints.

