

CREATE TABLE contacts (
    id INTEGER PRIMARY KEY,
    phone VARCHAR(20),
    name VARCHAR(100),
    address TEXT
);
